import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:tienda_login/pages/Acceder.dart';
import 'package:tienda_login/pages/Inicio.dart';
import 'package:tienda_login/pages/RegisterPage.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart';
import 'package:page_transition/page_transition.dart';

void main() {
  initializeDateFormatting().then((_) => runApp(LoginApp()));
}

class LoginApp extends StatelessWidget {
  const LoginApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter',
      home: LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  //crea una instancia de la clase TextEditingController llamada controllerUser.
  //Esta instancia se utiliza para controlar y gestionar un campo de entrada de texto
  TextEditingController controllerUser = new TextEditingController();
  TextEditingController controllerPass = new TextEditingController();
  final List<Widget> screens = [Acceder(), RegisterPage()];

  @override
  Widget build(BuildContext context) {
    final query = MediaQuery.of(context);
    return MediaQuery(
        data: query.copyWith(textScaleFactor: 1.0),
        child: MaterialApp(
          home: Scaffold(
            // La siguiente línea deshabilita la redimensión automática del contenido cuando aparece el teclado en la pantalla.
            resizeToAvoidBottomInset: false,
            // Configura el contenido principal de la pantalla dentro de un widget Form.
            body: Form(
              child: Container(
                decoration: BoxDecoration(
                  /*gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color(0xff313A56),
                      Color(0xff595A57),
                      Color(0xffF9DE5B),
                    ],
                  ),*/
                  color: Color(0xFF1D1B45),
                ),
                width: double.infinity,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Padding(padding: EdgeInsets.only(top: 10)),
                    Container(
                      child: Image.asset('assets/Mark1.png' // Ancho deseado
                          ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 50.0),
                      child: Container(
                        margin: EdgeInsets.fromLTRB(
                            15, 0, 0, 0), // Establece el margen
                        width: 260,
                        height:
                            48, // Establece el relleno (ajústalo según tus necesidades)

                        child: Text(
                          "¡Bienvenido!",
                          style: TextStyle(
                              color: Color(0xFFF9DE5B),
                              fontSize: 40,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Noto Sans'),
                        ),
                      ),
                    ),
                    SizedBox(height: 25),
                    //Container para el usuario
                    Container(
                      width: 220,
                      height: 49,
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                              context,
                              PageTransition(
                                  type: PageTransitionType.fade,
                                  child: screens[0]));
                        },
                        child: Text(
                          "Iniciar sesión",
                          style: TextStyle(
                              color: Color(0xFF1D1B45),
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Noto Sans'),
                        ),
                        style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all<Color>(
                              Color(0xFFF9DE5B)),
                          minimumSize:
                              MaterialStateProperty.all<Size>(Size(900, 600)),
                          shape:
                              MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(100.0),
                            ),
                          ),
                        ),
                      ),
                    ),

                    SizedBox(height: 32),
                    Container(
                      width: 220,
                      height: 49,
                      child: ElevatedButton(
                        onPressed: () => {
                          Navigator.push(
                              context,
                              PageTransition(
                                  type: PageTransitionType.fade,
                                  child: screens[1]))
                        },
                        child: Text(
                          "Registrarse",
                          style: TextStyle(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Noto Sans',
                              color: Color(0xFF1D1B45)),
                        ),
                        style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all<Color>(
                              Color(0xFFF9DE5B)), // Establece el color de fondo
                          foregroundColor: MaterialStateProperty.all<Color>(
                              Color(0xFFF313A56)),
                          minimumSize: MaterialStateProperty.all<Size>(
                              Size(200, 50)), // Establece el color del texto}
                          shape:
                              MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(100.0),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 140,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ));
  }
}
