import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart'; // Importa flutter_svg
import 'package:get/get.dart';
import 'package:tienda_login/pages/Estadisticas2.dart';
import 'package:page_transition/page_transition.dart';
import 'package:tienda_login/pages/Inicio.dart';
import 'package:tienda_login/pages/Inventario.dart';
import 'package:tienda_login/pages/RegisterPage.dart';
import 'package:tienda_login/pages/RegistroEm.dart';
import 'package:tienda_login/pages/Tareas.dart';

class Registro2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final query = MediaQuery.of(context);

    //Lista de todas las rutas
    final List<Widget> screens = [RegistroEm()];

    return MediaQuery(
      data: query.copyWith(textScaleFactor: 1.0),
      child: Scaffold(
        appBar: AppBar(
          elevation: 0, // Esta línea eliminará la sombra del AppBar
          backgroundColor: Color(0xFF1D1B45),
        ),
        // La siguiente línea deshabilita la redimensión automática del contenido cuando aparece el teclado en la pantalla.
        resizeToAvoidBottomInset: false,
        // Configura el contenido principal de la pantalla dentro de un widget Form.
        body: Form(
          child: Container(
            decoration: BoxDecoration(
              color: Color(0xFF1D1B45),
            ),
            width: double.infinity,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Padding(padding: EdgeInsets.only(top: 10)),
                Container(
                    //margin: EdgeInsets.only(bottom: 10),
                    child: Image.asset('assets/Mark1.png' // Ancho deseado

                        )),
                SizedBox(height: 20),
                Container(
                  child: Text(
                    "¡Bienvenido!",
                    style: TextStyle(
                        color: Color(0xFFF9DE5B),
                        fontSize: 31,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Noto Sans'),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 50.0),
                ),
                SizedBox(height: 10),
                //Container para el usuario
                Container(
                  width: 250,
                  height: 49,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          PageTransition(
                              type: PageTransitionType.fade,
                              child: screens[0]));
                    },
                    child: Text(
                      "Emprendimiento",
                      style: TextStyle(
                          color: Color(0xFF1D1B45),
                          fontSize: 25,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Noto Sans'),
                    ),
                    style: ButtonStyle(
                      backgroundColor:
                          MaterialStateProperty.all<Color>(Color(0xFFF9DE5B)),
                      minimumSize:
                          MaterialStateProperty.all<Size>(Size(900, 600)),
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(100.0),
                        ),
                      ),
                    ),
                  ),
                ),

                SizedBox(height: 32),
                Container(
                  width: 250,
                  height: 49,
                  child: ElevatedButton(
                    onPressed: () => {
                      Navigator.push(
                          context,
                          PageTransition(
                              type: PageTransitionType.fade, child: screens[0]))
                    },
                    child: Text(
                      "Inventario",
                      style: TextStyle(
                          fontSize: 25,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Noto Sans',
                          color: Color(0xFF1D1B45)),
                    ),
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all<Color>(
                          Color(0xFFF9DE5B)), // Establece el color de fondo
                      foregroundColor:
                          MaterialStateProperty.all<Color>(Color(0xFFF313A56)),
                      minimumSize: MaterialStateProperty.all<Size>(
                          Size(200, 50)), // Establece el color del texto}
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(100.0),
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 110,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
