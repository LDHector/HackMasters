import 'package:flutter/material.dart';
import 'package:tienda_login/pages/Inicio.dart';
import 'package:image_picker/image_picker.dart';
import 'package:tienda_login/pages/Inventario.dart';
import 'package:page_transition/page_transition.dart';
import 'package:tienda_login/pages/Registro2.dart';

class RegistroEm extends StatefulWidget {
  @override
  _RegistroEmState createState() => _RegistroEmState();
}

class _RegistroEmState extends State<RegistroEm> {
  final List<Widget> screens = [Inicio()];
  final List<String> negocio = [
    'Ninguno',
    'Accesorios',
    'Ropa',
    'Zapatos',
    'Farmacia',
    'Bisuteria',
    'Bebidas',
    'Otro'
  ];
  String dropdownValue = 'Ninguno'; // Valor seleccionado por defecto

  @override
  Widget build(BuildContext context) {
    final query = MediaQuery.of(context);
    return MediaQuery(
      data: query.copyWith(textScaleFactor: 1.0),
      child: Scaffold(
        appBar: AppBar(
          title: Text(" "),
          backgroundColor: Color(0xFF1D1B45),
        ),
        body: ListView.builder(
          itemCount: 1,
          itemBuilder: (context, index) {
            return Center(
              child: Container(
                padding: EdgeInsets.only(top: 20.0),
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Color(0xFF1D1B45),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    SizedBox(height: 6),
                    Container(
                      child: Container(
                        margin: EdgeInsets.fromLTRB(15, 0, 0, 0),
                        width: 296,
                        height: 80,
                        child: Stack(
                          children: [
                            Positioned(
                              width: 296,
                              height: 79,
                              top: -0,
                              child: Container(
                                child: Text(
                                  "Registro de Emprendimiento",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Color(0xFFF9DE5B),
                                    fontSize: 31,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Noto Sans',
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 40),
                    Container(
                      width: 300,
                      height: 35,
                      child: Text(
                        "Nombre del Emprendimiento",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Noto Sans'),
                      ),
                    ),
                    Container(
                      width: 305,
                      //// Márgenes horizontales de 20 puntos
                      margin: EdgeInsets.symmetric(horizontal: 20.0),
                      padding: EdgeInsets.all(
                          4.0), // // Relleno interno de 10 puntos
                      decoration: BoxDecoration(
                        color: Color(
                            0xFF37315E), // Color de fondo del TextFormField
                        borderRadius:
                            BorderRadius.circular(10.0), // Bordes redondeados
                      ),
                      child: Container(
                        height: 46,
                        width: 290,
                        child: TextFormField(
                          style: TextStyle(
                              color: Colors
                                  .white), // Establece el color del texto.
                          decoration: InputDecoration(
                            icon: Container(
                              padding: EdgeInsets.only(left: 5),
                              child: Icon(
                                //Agregamos un ícono al lado izquierdo del campo de entrada.
                                Icons.store,
                                color: Color(0xFF1D1B45),
                              ),
                            ),
                            /*hintText: '+505',
                            hintStyle: TextStyle(color: Colors.white),*/
                            // Establecemos un texto de sugerencia dentro del campo de entrada. En este caso, el texto es "Usuario".
                            //un borde visible.
                            border: InputBorder
                                .none, // Elimina el borde del TextFormField
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 30),
                    Container(
                      width: 300,
                      height: 35,
                      child: Text(
                        "Teléfono de contacto",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Noto Sans'),
                      ),
                    ),
                    Container(
                      width: 305,
                      //// Márgenes horizontales de 20 puntos
                      margin: EdgeInsets.symmetric(horizontal: 20.0),
                      padding: EdgeInsets.all(
                          4.0), // // Relleno interno de 10 puntos
                      decoration: BoxDecoration(
                        color: Color(
                            0xFF37315E), // Color de fondo del TextFormField
                        borderRadius:
                            BorderRadius.circular(10.0), // Bordes redondeados
                      ),
                      child: Container(
                        height: 46,
                        width: 290,
                        child: TextFormField(
                          style: TextStyle(
                              color: Colors
                                  .white), // Establece el color del texto.
                          decoration: InputDecoration(
                            icon: Container(
                              padding: EdgeInsets.only(left: 5),
                              child: Icon(
                                //Agregamos un ícono al lado izquierdo del campo de entrada.
                                Icons.phone,
                                color: Color(0xFF1D1B45),
                              ),
                            ),
                            /*hintText: '+505',
                            hintStyle: TextStyle(color: Colors.white),*/
                            // Establecemos un texto de sugerencia dentro del campo de entrada. En este caso, el texto es "Usuario".
                            //un borde visible.
                            border: InputBorder
                                .none, // Elimina el borde del TextFormField
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                    Container(
                      width: 300,
                      height: 35,
                      child: Text(
                        "Tipo de Emprendimiento",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Noto Sans'),
                      ),
                    ),
                    Container(
                      width: 305,
                      margin: EdgeInsets.symmetric(horizontal: 20.0),
                      padding: EdgeInsets.all(4.0),
                      decoration: BoxDecoration(
                        color: Color(0xFF37315E),
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      child: Container(
                        height: 46,
                        width: 290,
                        child: DropdownButton<String>(
                          value: dropdownValue,
                          icon: Container(
                              padding: EdgeInsets.only(left: 70),
                              child: const Icon(Icons.arrow_downward_sharp)),
                          iconEnabledColor: Colors.white,
                          elevation: 16,
                          padding: EdgeInsets.only(left: 95),
                          style: const TextStyle(
                            color: Colors
                                .white, // Ajusta el color del texto del menú desplegable
                            fontSize: 18,
                          ),
                          dropdownColor: Color(
                              0xFF37315E), // Ajusta el color de fondo del menú desplegable
                          underline: Container(
                            height: 0,
                            color: Colors.white,
                          ),
                          onChanged: (String? value) {
                            if (value != null) {
                              setState(() {
                                dropdownValue = value;
                              });
                            }
                          },
                          items: negocio
                              .map<DropdownMenuItem<String>>((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                    SizedBox(height: 100),
                    Container(
                      child: Padding(
                        padding: EdgeInsets.only(top: 30.0),
                        child: ElevatedButton(
                          onPressed: () => {
                            Navigator.push(
                                context,
                                PageTransition(
                                    type: PageTransitionType.fade,
                                    child: screens[0]))
                          },
                          child: Text(
                            "Continuar",
                            style: TextStyle(
                                fontSize: 25,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Noto Sans'),
                          ),
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                Color(0xFFF9DE5B)),
                            foregroundColor: MaterialStateProperty.all<Color>(
                                Color(0xFF1D1B45)),
                            minimumSize:
                                MaterialStateProperty.all<Size>(Size(200, 50)),
                            shape: MaterialStateProperty.all<
                                RoundedRectangleBorder>(
                              RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(100.0),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 350),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
