import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart'; // Importa flutter_svg
import 'package:get/get.dart';
import 'package:tienda_login/pages/Estadisticas2.dart';
import 'package:page_transition/page_transition.dart';
import 'package:tienda_login/pages/Inicio.dart';
import 'package:tienda_login/pages/Inventario.dart';
import 'package:tienda_login/pages/RegisterPage.dart';
import 'package:tienda_login/pages/Tareas.dart';

class Acceder extends StatelessWidget {
  final _formKey =
      GlobalKey<FormState>(); // Agrega un GlobalKey para el formulario
  @override
  Widget build(BuildContext context) {
    final query = MediaQuery.of(context);

    //Lista de todas las rutas
    final List<Widget> screens = [
      Inicio(),
      Estadisticas(),
      Inventario(),
      Tareas()
    ];

    return MediaQuery(
      data: query.copyWith(textScaleFactor: 1.0),
      child: Scaffold(
        appBar: AppBar(
          elevation: 0, // Esta línea eliminará la sombra del AppBar
          backgroundColor: Color(0xFF1D1B45),
        ),
        // La siguiente línea deshabilita la redimensión automática del contenido cuando aparece el teclado en la pantalla.
        resizeToAvoidBottomInset: false,
        // Configura el contenido principal de la pantalla dentro de un widget Form.
        body: Form(
          key: _formKey,
          child: Container(
            decoration: BoxDecoration(
              /*gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color(0xff313A56),
                      Color(0xff595A57),
                      Color(0xffF9DE5B),
                    ],
                  ),*/
              color: Color(0xFF1D1B45),
            ),
            width: double.infinity,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Padding(padding: EdgeInsets.only(top: 10)),
                Container(
                    //margin: EdgeInsets.only(bottom: 10),
                    child: Image.asset('assets/Mark1.png' // Ancho deseado

                        )),
                Padding(
                  padding: const EdgeInsets.only(top: 50.0),
                ),
                SizedBox(height: 10),
                //Container para el usuario
                Container(
                  width: 300,
                  height: 35,
                  child: Text(
                    "Correo electrónico",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Noto Sans'),
                  ),
                ),
                Container(
                  width: 305,
                  //// Márgenes horizontales de 20 puntos
                  margin: EdgeInsets.symmetric(horizontal: 20.0),
                  padding:
                      EdgeInsets.all(4.0), // // Relleno interno de 10 puntos
                  decoration: BoxDecoration(
                    color:
                        Color(0xFF37315E), // Color de fondo del TextFormField
                    borderRadius:
                        BorderRadius.circular(10.0), // Bordes redondeados
                  ),
                  child: Container(
                    height: 46,
                    width: 290,
                    child: Container(
                      height: 80,
                      child: TextFormField(
                        style: TextStyle(
                            color:
                                Colors.white), // Establece el color del texto.
                        decoration: InputDecoration(
                          icon: Container(
                            padding: EdgeInsets.only(left: 5),
                            child: Icon(
                              //Agregamos un ícono al lado izquierdo del campo de entrada.
                              Icons.email,
                              color: Color(0xFF1D1B45),
                            ),
                          ),
                          // Establecemos un texto de sugerencia dentro del campo de entrada. En este caso, el texto es "Usuario".

                          // Eliminamos el borde del TextFormField para que no tenga un borde visible.
                          border: InputBorder
                              .none, // Elimina el borde del TextFormField
                        ),

                        onSaved: (String? value) {
                          // This optional block of code can be used to run
                          // code when the user saves the form.
                        },
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Por favor ingrese su correo electrónico';
                          }
                          return null;
                        },
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 25),

                Container(
                  width: 300,
                  height: 35,
                  child: Text(
                    "Contraseña",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Noto Sans'),
                  ),
                ),
                Container(
                  width: 305,
                  //// Márgenes horizontales de 20 puntos
                  margin: EdgeInsets.symmetric(horizontal: 20.0),
                  padding:
                      EdgeInsets.all(4.0), // // Relleno interno de 10 puntos
                  decoration: BoxDecoration(
                    color:
                        Color(0xFF37315E), // Color de fondo del TextFormField
                    borderRadius:
                        BorderRadius.circular(10.0), // Bordes redondeados
                  ),
                  child: Container(
                    height: 46,
                    width: 290,
                    child: TextFormField(
                      obscureText: true,
                      style: TextStyle(
                          color: Colors.white), // Establece el color del texto.
                      decoration: InputDecoration(
                        hintText: '',
                        icon: Container(
                          padding: EdgeInsets.only(left: 5),
                          child: Icon(
                            //Agregamos un ícono al lado izquierdo del campo de entrada.
                            Icons.lock,
                            color: Color(0xFF1D1B45),
                          ),
                        ),
                        // Establecemos un texto de sugerencia dentro del campo de entrada. En este caso, el texto es "Usuario".

                        // Eliminamos el borde del TextFormField para que no tenga un borde visible.
                        border: InputBorder
                            .none, // Elimina el borde del TextFormField
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Por favor ingrese su contraseña';
                        }
                        return null;
                      },
                    ),
                  ),
                ),
                SizedBox(height: 25),
                Container(
                    child: Padding(
                  padding: EdgeInsets.only(top: 30.0),
                  child: ElevatedButton(
                    onPressed: () => {
                      if (_formKey.currentState!.validate())
                        {
                          Navigator.pop(context),
                        }
                    },
                    child: Text(
                      "Acceder",
                      style: TextStyle(
                          fontSize: 25,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Noto Sans',
                          color: Color(0xFF1D1B45)),
                    ),
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all<Color>(
                          Color(0xFFF9DE5B)), // Establece el color de fondo
                      foregroundColor:
                          MaterialStateProperty.all<Color>(Color(0xFFF313A56)),
                      minimumSize: MaterialStateProperty.all<Size>(
                          Size(200, 50)), // Establece el color del texto}
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(100.0),
                        ),
                      ),
                    ),
                  ),
                )),
                SizedBox(
                  height: 110,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
